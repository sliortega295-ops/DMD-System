# 2026-08-18 current status

## H3-DMD-for-A100

The shared-backbone world16 primary capacity path remains blocked. The latest bounded candidate (segment=8 plus saved-tensor CPU offload) still failed at the first Student backward/recompute allocation. No H3 Full5 timing was run. CP/SP2 is not run because a semantically correct MiniMax-H3 integration is not available in the pinned LightX2V path.

## DMD-System own path

At DMD-System HEAD `295f98ca3d5828475f4aca5d709e322bcf82c30d`, LightX2V `d034a6b0ecaa31aa07c81aeb7bbe69b225f1d7be`, world16, BF16, 768x1344x124, B1/rank, fixed `end_step_idx=3`, `_flash_3_hub`, and the exact all-boundary checkpoint CPU policy:

- phase-cluster candidate: 16/16 structural/capacity PASS, 31 application forwards, 6 backward graphs, 1 Student update, 5 Fake updates, 914.102536 s one cycle, no new OOM.
- native control: 16/16 structural/capacity PASS, same census and samples, 917.993973 s one cycle, no new OOM.

Apparent one-run reduction is 3.891437 s / 0.4240%; this is below the project performance claim threshold and is not a formal speedup.

Important: direct state-hash comparison is not equivalent. Student params/optimizer match on 16/16 ranks, but Fake params and Fake optimizer match on 0/16 ranks despite equal recorded sample IDs. Marked `CROSS_SCHEDULE_STATE_PARITY_FAIL`; no Full5 should start until random latent/sigma/noise and Fake update inputs are operation-keyed and reconciled.

All owned workers were cleaned, both nodes report zero GPU memory after teardown, and cgroup OOM deltas for these runs are zero.
