# MiniMax-H3 DMD-System phase-cluster one-cycle status

Run ID: `minimax_distschedule_phase_cluster_onecycle_20260818`

## Contract

- DMD-System HEAD: `295f98ca3d5828475f4aca5d709e322bcf82c30d`
- LightX2V: `d034a6b0ecaa31aa07c81aeb7bbe69b225f1d7be`
- Official shape: 768x1344, 124 frames, BF16
- World: 2 nodes x 8 A100, world16, B1/rank
- Fixed `end_step_idx=3`, continuous sigma, `_flash_3_hub`
- Student/Fake/Teacher application census: 24/6/1 forwards; 1/5/0 grad forwards; 1/5 backwards
- Activation policy: checkpoint-boundary CPU staging, exact all-50-boundary manifest

## Result

`PASS` for one outer cycle: 16/16 ranks, finite execution, and no new cgroup OOM.

- Student optimizer updates: 1
- Fake optimizer updates: 5
- Total forwards: 31
- Total backward graphs: 6
- Cycle wall: 914.102536 s (diagnostic one-cycle, not Full5 timing)
- Max allocated: 30,171,320,832 B (28.10 GiB)
- Max reserved: 41,049,653,248 B (38.23 GiB)
- cgroup OOM delta: node0=0, node1=0
- GPU processes: cleaned after completion

The phase-cluster schedule preserves the application census and sample identity contract. The run is a capacity/correctness result; it is not a formal Full5 speed claim.

## Comparison boundary

A same-HEAD native one-cycle control with the same trace, source, checkpoint-boundary policy, and manifest is running as `minimax_native_phase_cluster_onecycle_20260818`. Its result is not yet available and no speedup is claimed until it completes and passes the same receipt gates.

## Not run

Formal Full5, three repetitions, H3 CP/SP2, and any new memory optimization are not run in this bounded step.

## Same-HEAD native control

Run ID: `minimax_native_phase_cluster_onecycle_20260818`

- Status: `PASS`
- Same DMD-System HEAD, LightX2V source, model, prompt cache, seed, manifest, and activation policy
- Cycle wall: 917.993973 s
- Max allocated: 29,997,760,512 B (27.94 GiB)
- Max reserved: 41,049,653,248 B (38.23 GiB)
- cgroup OOM delta: node0=0, node1=0
- Same application census: 24/6/1 forwards, 1/5/0 grad forwards, 1/5 backwards

The one paired observation is:

- phase-cluster: 914.102536 s
- native: 917.993973 s
- absolute difference: 3.891437 s
- apparent reduction: 0.4240%

This is a single diagnostic one-cycle observation, not a formal speedup claim. The difference is below the preregistered 10% performance threshold and needs repeated matched timing before any performance interpretation.

## Cross-schedule state parity audit

The structural summarizer reports PASS for both runs, but direct comparison of the saved state hashes finds:

- Student parameter hash: 16/16 equal
- Student optimizer hash: 16/16 equal
- Fake parameter hash: 0/16 equal
- Fake optimizer hash: 0/16 equal
- Recorded sample sequence: equal

Therefore this is **not yet a full mathematical equivalence PASS** for the reordered schedule. The phase-cluster candidate is capacity-valid and census-valid, but its Fake post-update state differs from the native control. No Full5 or speedup claim is permitted until the source of this state divergence is explained or the candidate is rejected.
