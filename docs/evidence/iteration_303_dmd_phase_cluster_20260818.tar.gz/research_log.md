
## Iteration 303-DMD-phase-cluster-20260818

### Question
Can the DMD-System phase-cluster schedule run the exact MiniMax-H3 world16 one-cycle contract with checkpoint-boundary CPU staging?

### Hypothesis
The phase-cluster schedule changes only ordering (Student update, five no-grad Student rollouts, then ordered Fake updates) while preserving the exact 31-forward/6-backward application census and can fit without OOM.

### Evidence
Run `minimax_distschedule_phase_cluster_onecycle_20260818` on DMD-System HEAD `295f98ca3d5828475f4aca5d709e322bcf82c30d`, LightX2V `d034a6b0ecaa31aa07c81aeb7bbe69b225f1d7be`, world16, 768x1344x124, BF16, B1/rank, fixed end_step_idx=3, exact all-boundary manifest.

### Result
Measured: PASS. 16/16, 31 forwards, 6 backwards, 1 Student update, 5 Fake updates, no cgroup OOM. Cycle wall 914.102536 s; max allocated 30,171,320,832 B; max reserved 41,049,653,248 B.

### Interpretation
The own DMD-System phase-cluster candidate is capacity/correctness viable for one cycle. It is not yet a formal performance result. A matched native same-HEAD one-cycle control is running before any timing conclusion.

### Not Run
Formal Full5, repeated timing, and H3 CP/SP2 remain Not Run.

### Matched control update

The same-HEAD native control `minimax_native_phase_cluster_onecycle_20260818` also PASSed: 16/16, exact application census, max allocated 29,997,760,512 B, max reserved 41,049,653,248 B, no new cgroup OOM, global cycle 917.993973 s. The phase-cluster candidate was 914.102536 s in one run, an apparent 3.891437 s (0.4240%) reduction. This is below the 10% claim threshold and is not a formal speedup result; repeated matched timing is Not Run.

### Important parity limitation

After both one-cycle summaries completed, direct state-hash comparison showed Student params/optimizer equal on all 16 ranks and sample sequence equal, but Fake params and Fake optimizer unequal on all 16 ranks between native and phase-cluster. The existing structural summarizer did not check cross-run state parity. Marked `CROSS_SCHEDULE_STATE_PARITY_FAIL` for the candidate; no Full5/timing claim. The next question is whether reordered Fake updates change an unrecorded RNG/latent/optimizer input or expose a numerical-order dependency. Do not proceed to formal timing until resolved.
