# Append-only research log

## Iteration 300 — segment=8 bounded MiniMax world16 canary — 2026-08-18

### Milestone / Gate
MiniMax-H3 FSDP-first capacity gate; Student forward then Student update. No full cycle until update passes.

### Question
Can pure-GPU segmented checkpointing with segment=8 complete the real world16 Student grad forward and the subsequent Student update without activation CPU offload?

### Hypothesis
Seven checkpoint segment boundaries may lower the forward peak enough for a full grad-enabled Student forward, but backward recomputation may expose a separate working-set peak.

### Evidence Needed
Per-segment saved-tensor/allocator progress, rank-consistent block failure location, CUDA/cgroup status, and explicit PASS/FAIL/NOT_RUN gates.

### Allowed Changes
Only pre-registered segmented-checkpoint canary/debug instrumentation and launcher propagation. No model, loss, trace, precision, optimizer, topology, or activation-offload changes.

### Commands
See manifest.json for exact commands and environment paths. Flags were:
LIGHTX2V_MINIMAX_CHECKPOINT_SEGMENT=8
LIGHTX2V_MINIMAX_SEGMENT_DEBUG=1
LIGHTX2V_MINIMAX_MEMORY_ATTRIBUTION=1
LIGHTX2V_MINIMAX_ACTIVATION_OFFLOAD=0

### Measured Results
- Student-forward canary: PASS, 16/16 debug streams; 4 Student forwards/rank (3 no-grad + 1 grad-enabled); all 7 segment exits and all 50 blocks completed.
- Forward process peak: 27,453,071,872 B allocated and 33,611,055,104 B reserved.
- Student-update canary: FAIL_CUDA_OOM during backward/recompute, all 16 ranks at segment 6 / block 49; attempted allocation 2.02 GiB; median allocated 39,362,631,680 B and reserved 41,213,231,104 B at error.
- cgroup OOM delta: node0 0, node1 0; node0 historical oom_kill counter remained 4.
- No optimizer commit and no full native cycle.

### Correctness
Forward-only gate PASS. Update correctness is NOT_RUN because the backward failed. No claim of native Student1+Fake5 correctness.

### Performance
NOT_RUN. No timing, Nsight, or speedup claim.

### Interpretation
Segment=8 resolves the earlier forward-boundary concern but is insufficient for the backward/recompute peak under pure GPU storage. This is a bounded negative result for Student update capacity, not evidence about CPU activation offload or an alternative static working-set policy.

### Files / Artifacts
All raw receipts remain under the two run directories. Analysis outputs are under tables/. No old artifact was overwritten.

### Gate Status
STOPPED_AFTER_STUDENT_UPDATE_OOM.

### Next Highest-Value Question
Choose one pre-registered next mechanism: a different checkpoint segmentation (CP=2/4) or reducing simultaneous static Fake/Teacher working set. Do not run full native until Student update passes.

### Next Command
NOT_RUN pending user authorization.
