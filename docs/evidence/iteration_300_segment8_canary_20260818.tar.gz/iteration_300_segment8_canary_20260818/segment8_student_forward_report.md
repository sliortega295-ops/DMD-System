# Segment-8 Student grad-enabled forward

Status: PASS. World16 produced 16 debug streams. Four Student forwards were observed per rank; the fourth grad-enabled forward traversed all 50 blocks and all seven segment boundaries. No block error, CUDA OOM, or cgroup OOM delta occurred. See tables/segment8_canary_analysis.md for the segment table.
