# MiniMax-H3 segment=8 bounded world16 canary

- **Run ID:** iteration_300_segment8_canary_20260818
- **Code:** agent/lightx2v-minimax-fsdp-first-segmented-checkpoint-20260818 @ 8ef6f78566ab31476cb5c724f7f048d2538a8f89
- **Upstream LightX2V:** d034a6b0ecaa31aa07c81aeb7bbe69b225f1d7be
- **Benchmark patch:** 89935efd36d8a149f121b428cad700363d987918718b81b1ea56b887f196d9c3
- **World:** 2 nodes x 8 A100-SXM4-40GB, world16
- **Workload:** MiniMax-H3, BF16, FSDP2 FULL_SHARD, 50 transformer blocks, one fully_shard per block, [B,16,9,48,80]
- **Policy:** checkpoint_segment=8, parameter offload=false, activation offload=false, model swap=false, _flash_3_hub
- **Debug flags:** LIGHTX2V_MINIMAX_SEGMENT_DEBUG=1, LIGHTX2V_MINIMAX_MEMORY_ATTRIBUTION=1, LIGHTX2V_MINIMAX_ACTIVATION_OFFLOAD=0
- **Diffusers:** 0.40.0.dev0, source 9284607295a09f759aadd65ed08f48b35feea6d9, pinned MiniMax forward SHA256 3e041a3400d58cf73d69e4eb540317d45b5f9631a73bb8e765447ca446ee1d41

## Gate status

| Gate | Status | Evidence |
|---|---|---|
| Student grad-enabled forward (world16) | **PASS** | 16 debug streams; four Student forwards/rank (three no-grad + one grad-enabled); all 50 blocks/7 segments exit |
| Student update (forward + backward + optimizer) | **FAIL: CUDA OOM** | all 16 ranks fail during backward recomputation at segment 6, block 49 |
| Full native Student1 + Fake5 | **NOT_RUN** | stopped after update failure |
| Formal timing / Nsight / GAN-on | **NOT_RUN** | outside bounded canary |

## Student grad-forward segment table

These rows are the final grad-enabled forward in each canary. saved live is the debug hook's saved-tensor estimate; allocated and reserved are CUDA allocator values captured at segment exit. driver free was not captured at each segment boundary and is intentionally not inferred.

| segment | block range | saved live (GiB, median) | allocated (GiB, median) | reserved (GiB, median) | driver free |
|---:|:---:|---:|---:|---:|:---|
| 0 | 0-7 | 0.379 | 14.887 | 29.287 | NOT_CAPTURED |
| 1 | 8-15 | 0.757 | 15.265 | 29.287 | NOT_CAPTURED |
| 2 | 16-23 | 1.134 | 15.642 | 29.287 | NOT_CAPTURED |
| 3 | 24-31 | 1.512 | 16.020 | 31.303 | NOT_CAPTURED |
| 4 | 32-39 | 1.890 | 16.398 | 31.303 | NOT_CAPTURED |
| 5 | 40-47 | 2.268 | 16.776 | 31.303 | NOT_CAPTURED |
| 6 | 48-49 | 2.646 | 17.154 | 31.303 | NOT_CAPTURED |

The complete forward process peak (including non-boundary runtime allocations) was 27,453,071,872 B allocated (25.568 GiB) and 33,611,055,104 B reserved (31.303 GiB). No cgroup OOM delta occurred on either node.

## Student-update failure localization

The update canary completed the same four Student forwards, then entered backward/recompute. The first failing operation was identical on all 16 ranks:

- segment: 6, blocks 48-49
- block: 49
- operation: Student backward/recompute
- allocation requested: 2.02 GiB
- allocated at error: median 39,362,631,680 B (36.660 GiB), range 39,360,981,504–39,363,455,488 B
- reserved at error: median 41,213,231,104 B (38.385 GiB), range 41,213,231,104–41,234,202,624 B
- rank-0 CUDA error text: 242.38 MiB free; 36.66 GiB allocated by PyTorch and 1.72 GiB reserved-but-unallocated
- debug saved tensors at failing block: median 2,434,995,544 B (2.267 GiB); pack total 3,684,194,672 B (3.431 GiB); unpack total 1,248,984,064 B (1.163 GiB)
- cgroup: node0 oom delta 0 and oom_kill delta 0 (historical counter stayed at 4); node1 deltas 0/0
- optimizer: no successful optimizer commit was produced

Thus segment=8 crosses the previous forward peak, but it does not provide enough headroom for the backward/recomputation working set.

## Interpretation and stop boundary

This is a bounded negative result for the pure-GPU segment=8 Student update, not a result for CPU activation offload. The failure is not in the grad-enabled forward: it occurs at the last block of the backward/recompute traversal after the forward graph has been built. No full native cycle was launched, and there is no timing or speedup claim.

The next decision is therefore still open between:
1. a separately preregistered checkpoint-policy experiment (for example CP=2/4), or
2. reducing the simultaneous static working set (for example shared Fake/Teacher construction policy).

This run did not test either option.

## Cleanup

The two nodes had no live CUDA compute processes after the run and ports 29982/29983 were not listening. A pre-existing defunct torchrun parent on node0 had no GPU context and was not touched. No other user's process was modified.

## Artifacts

- Manifest: manifest.json
- Segment analysis: tables/segment8_canary_analysis.md
- Machine-readable segment analysis: tables/segment8_canary_analysis.json
- CSV: tables/segment8_canary_segment_table.csv
- Forward raw evidence: segment8_student_forward_20260818_r1/native/
- Update raw evidence: segment8_student_update_20260818_r1/native/
- Analysis script: scripts/summarize_segment8_canary.py
- Manifest checksum: manifest.sha256
