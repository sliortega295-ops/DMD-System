Segment-8 bounded canary analysis

driver_free_bytes is intentionally NOT_CAPTURED: the debug hook records allocator allocated/reserved and saved-tensor estimates, not NVML driver-free at each segment boundary.

## student_forward

| segment | blocks | saved live (GiB) | allocated (GiB) | reserved (GiB) | driver free |
|---:|:---:|---:|---:|---:|:---|
| 0 | 0-7 | 0.379 | 14.887 | 29.287 | NOT_CAPTURED |
| 1 | 8-15 | 0.757 | 15.265 | 29.287 | NOT_CAPTURED |
| 2 | 16-23 | 1.134 | 15.642 | 29.287 | NOT_CAPTURED |
| 3 | 24-31 | 1.512 | 16.020 | 31.303 | NOT_CAPTURED |
| 4 | 32-39 | 1.890 | 16.398 | 31.303 | NOT_CAPTURED |
| 5 | 40-47 | 2.268 | 16.776 | 31.303 | NOT_CAPTURED |
| 6 | 48-49 | 2.646 | 17.154 | 31.303 | NOT_CAPTURED |

No block error in debug stream.

## student_update

| segment | blocks | saved live (GiB) | allocated (GiB) | reserved (GiB) | driver free |
|---:|:---:|---:|---:|---:|:---|
| 0 | 0-7 | 0.379 | 14.887 | 29.287 | NOT_CAPTURED |
| 1 | 8-15 | 0.757 | 15.265 | 29.287 | NOT_CAPTURED |
| 2 | 16-23 | 1.134 | 15.642 | 29.287 | NOT_CAPTURED |
| 3 | 24-31 | 1.512 | 16.020 | 31.303 | NOT_CAPTURED |
| 4 | 32-39 | 1.890 | 16.398 | 31.303 | NOT_CAPTURED |
| 5 | 40-47 | 2.268 | 16.776 | 31.303 | NOT_CAPTURED |
| 6 | 48-49 | 2.646 | 17.154 | 31.303 | NOT_CAPTURED |

First block error: rank 0, segment 6 (blocks 48-49), block 49; allocated 36.660 GiB, reserved 38.385 GiB.

