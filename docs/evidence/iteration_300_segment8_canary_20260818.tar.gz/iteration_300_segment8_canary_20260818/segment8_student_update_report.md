# Segment-8 Student update

Status: FAIL_CUDA_OOM_DURING_BACKWARD_RECOMPUTE. All 16 ranks reached segment 6 / block 49 of the Student backward/recompute traversal and failed a 2.02 GiB allocation. The grad-enabled forward itself completed; no optimizer commit was produced. CPU activation offload was disabled. See segment8_canary_report.md and the raw per-rank debug JSONL.
