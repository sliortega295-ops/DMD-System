#!/usr/bin/env python3
import csv, json, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[0].parent
RUNS = {
    "student_forward": ROOT / "segment8_student_forward_20260818_r1" / "native",
    "student_update": ROOT / "segment8_student_update_20260818_r1" / "native",
}

def gi(b):
    return b / (1024 ** 3) if b is not None else None

def read_events(run):
    out = {}
    for p in sorted((run / "raw" / "receipts").glob("rank_*.segment_debug.jsonl")):
        rank = int(p.name.split("_")[1].split(".")[0])
        out[rank] = [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
    return out

def final_forward_rows(events, role="student"):
    rows = [e for e in events if e.get("role") == role and e.get("event") == "segment_exit"]
    if len(rows) < 7:
        return []
    return rows[-7:]

def summarize_rows(all_rows):
    output = []
    for idx in range(7):
        rows = [r[idx] for r in all_rows if len(r) == 7]
        template = rows[0]
        output.append({
            "segment": template["segment"],
            "block_start": template["segment_start"],
            "block_end_exclusive": template["segment_end"],
            "block_range": f'{template["segment_start"]}-{template["segment_end"]-1}',
            "ranks": len(rows),
            "saved_live_bytes_median": int(statistics.median(r["saved_tensor_bytes"] for r in rows)),
            "saved_live_bytes_min": min(r["saved_tensor_bytes"] for r in rows),
            "saved_live_bytes_max": max(r["saved_tensor_bytes"] for r in rows),
            "allocated_bytes_median": int(statistics.median(r["allocated_bytes"] for r in rows)),
            "allocated_bytes_min": min(r["allocated_bytes"] for r in rows),
            "allocated_bytes_max": max(r["allocated_bytes"] for r in rows),
            "reserved_bytes_median": int(statistics.median(r["reserved_bytes"] for r in rows)),
            "reserved_bytes_min": min(r["reserved_bytes"] for r in rows),
            "reserved_bytes_max": max(r["reserved_bytes"] for r in rows),
            "driver_free_bytes": None,
        })
    return output

payload = {"schema_version": "distillschedule.segment8_canary_analysis.v1", "runs": {}}
for name, run in RUNS.items():
    events_by_rank = read_events(run)
    final_rows = [final_forward_rows(events) for events in events_by_rank.values()]
    summary = summarize_rows(final_rows)
    errors = []
    for rank, events in events_by_rank.items():
        for e in events:
            if e.get("event") == "block_error":
                errors.append({"rank": rank, **e})
    payload["runs"][name] = {
        "rank_count": len(events_by_rank),
        "student_final_grad_forward": summary,
        "block_errors": errors,
        "event_count_by_rank": {str(k): len(v) for k,v in events_by_rank.items()},
    }

out_json = ROOT / "tables" / "segment8_canary_analysis.json"
out_json.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
out_csv = ROOT / "tables" / "segment8_canary_segment_table.csv"
with out_csv.open("w", newline="") as f:
    fields = ["run", "segment", "block_range", "ranks",
              "saved_live_bytes_median", "saved_live_bytes_min", "saved_live_bytes_max",
              "allocated_bytes_median", "allocated_bytes_min", "allocated_bytes_max",
              "reserved_bytes_median", "reserved_bytes_min", "reserved_bytes_max",
              "driver_free_bytes"]
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
    for run_name, run_data in payload["runs"].items():
        for row in run_data["student_final_grad_forward"]:
            w.writerow({"run": run_name, **{k: row[k] for k in fields if k in row}})

md = []
md.append("Segment-8 bounded canary analysis\n")
md.append("driver_free_bytes is intentionally NOT_CAPTURED: the debug hook records allocator allocated/reserved and saved-tensor estimates, not NVML driver-free at each segment boundary.\n")
for run_name, run_data in payload["runs"].items():
    md.append(f"## {run_name}\n")
    md.append("| segment | blocks | saved live (GiB) | allocated (GiB) | reserved (GiB) | driver free |")
    md.append("|---:|:---:|---:|---:|---:|:---|")
    for r in run_data["student_final_grad_forward"]:
        md.append(f"| {r['segment']} | {r['block_range']} | {gi(r['saved_live_bytes_median']):.3f} | {gi(r['allocated_bytes_median']):.3f} | {gi(r['reserved_bytes_median']):.3f} | NOT_CAPTURED |")
    if run_data["block_errors"]:
        e = run_data["block_errors"][0]
        md.append(f"\nFirst block error: rank {e['rank']}, segment {e['segment']} (blocks {e['segment_start']}-{e['segment_end']-1}), block {e['block']}; allocated {gi(e['allocated_bytes']):.3f} GiB, reserved {gi(e['reserved_bytes']):.3f} GiB.\n")
    else:
        md.append("\nNo block error in debug stream.\n")
(ROOT / "tables" / "segment8_canary_analysis.md").write_text("\n".join(md) + "\n")
